#include<iostream>                 
#include<iomanip>                         
#include<cmath>
#include<windows.h>        // Header Files //
#include<conio.h>
#include<process.h>
#include<string>
#include<fstream>   
using namespace std;

void Welcome();             // Declaration of Welcome Function
void Login();               // Declaration of Login Function 
void Registration();        // Declaration of Registration Function      
void Exit();                // Declaration of Exit Function
void manu();                // Declaraion of manu Function
void Chicken();             // Declaration of Chicken Function
void Mutton();              // Declaration of Mutton Function
void DesiFood();            // Declaration of Desi Food Function
void Biryani();             // Declaration of Biryani Function
void Burger();              // Declaration of Burger Function
void Main();
int main(){	 
Welcome();
getche(); 
ShowWindow(GetConsoleWindow(),SW_MAXIMIZE);	


Main();

			
getch();
return 0;	
}       


void Registration()          // Definition of Registration Function.
{
int choice;
//system("color 5E");
string username,password,CNIC,contactnumber,Email,Add;
system("cls");
cout<<endl<<endl<<endl;
cout<<"\t\t\t\t\tEnter your name:  ";
cin>>username;
cout<<"\n\t\t\t\t\tEntre your CNIC number:  "; cin>>CNIC;
cout<<"\n\t\t\t\t\tEntre your contact number:  "; cin>>contactnumber;
cout<<"\n\t\t\t\t\tEntre your Email:  "; cin>>Email;
cout<<"\n\t\t\t\t\tEntre your Residency:  "; cin>>Add;
cout<<"\n\t\t\t\t\tEnter your Password:  ";
cin>>password;
ofstream outfile;
outfile.open("User.text");
outfile<<username<<"\n"<<password<<"\n"<<CNIC<<"\n"<<contactnumber<<"\n"<<Email<<"\n"<<Add;
outfile.close();
cout<<"\n\n\t\t\t\t\tRegistered Successfuly\n";
char cp;
cout<<"\n\n\t\t\t\t\tEntre your choice  ";
cout<<"\n\n\t\t\t\t\tPress l or L to login OR m or M to go into main function:  ";
cin>>cp;
if (cp=='m'||cp=='M')
{
   Main();
}
if (cp=='l'||cp=='L')
{
   Login();
   
}
else 
cout<<"\n\t\t\t\t\t\aInvalid Key: "<<endl;	
}

void Login()          // Definition of Login Function.
{
system("cls");
char ch,cn;
int choice;
//system("color 2F");
string FileString,FilePassword,idname,idpassword;
int exist=0;
cout<<endl<<endl;
cout<<"\t\t\t\t\t\t\tEnter the username:\t";
cin>>idname;
cout<<"\t\t\t\t\t\t\tEnter the password:\t";
cin>>idpassword;
ifstream infile;
infile.open("User.text");
infile>>FileString>>FilePassword;
infile.close();
if(FileString==idname && FilePassword==idpassword)
{
cout<<endl;
cout<<"\t\t\t\t\t\t\tLogin Has been done successfully"<<endl;
cout<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t ===================================================================== "<<endl;
cout<<"\t\t\t\t\t W E L C O M E   T O   O N L I N E   R E S T A U R A N T   S Y S T E M "<<endl;
cout<<"\t\t\t\t\t ===================================================================== "<<endl;
cout<<endl;
cout<<"\t\t\t\t\t\t\tPress any key to go into menu   ";
getche();

{
   manu();
}	
}
else {
cout<<"\n\n\a\t\t\t\t\t\t\tInvalid  User or Password !!\n";
cout<<"\n\n\t\t\t\t\t\t\t Press m or M to go to main or l or l to login again: ";
char cp;
cin>>cp;
if (cp=='m'||cp=='M')
{
Main();	
}
else
{
Login();
}
}

}


void manu()
{   
system("cls");
system("color 7C");
cout<<endl<<endl<<endl;
cout<<"\t\tSelect the item for order\n ";
cout<<"\t\t============================\n";
cout<<"\t\t1: Chicken\n";
cout<<"\t\t2: Mutton\n";
cout<<"\t\t3: Deesi Food\n";
cout<<"\t\t4: Biryani\n";
cout<<"\t\t5: Burger\n";
cout<<"\t\t6: Go to Main\n";
char choice; cout<<endl<<endl;
cout<<"\t\t\t\t\t\t\t Enter your Choice (One order at a time) !!  ";
cin>>choice;
if (choice=='1')
{
Chicken();                   // Calling Chicken Function
}
else if (choice=='2')
{
Mutton();	                // Calling Mutton Function
}
else if (choice=='3')
{
DesiFood();                 // Calling Desi Food Function
}
else if (choice=='4')
{
Biryani();                  // Calling Biryani Function
}
else if (choice=='5')
{
Burger();                   // Calling burger Function
}
else
{
cout<<"\n\t\t\t\t\t\t\t Invalid Choice:  ";
} 	
}



void Chicken()      // Definition of Chicken Function:
{
  
int item,Kg;
int a,b,c,d,e,f,g,h,i,j,s1=0;	
system("cls");
system("color 0F");
cout<<endl<<endl<<endl;
cout<<"\t\t\t  =========================================================================================\n";
cout<<"\t\t\t  1.   Chicken Karhai RS.850\t\t\t\t 2.   Chicken Boneless Handi RS.850\n\t\t\t  3.   Chicken Achari Karhai RS.850 \t\t\t 4.   Chicken Jalfrezi RS.400\n ";
cout<<"\t\t\t  5.   Chicken Green Chilli RS.400 \t\t\t 6.   Chicken Vegetable RS.400\n\t\t\t  7.   Chicken Malai Boti RS.450 \t\t\t 8.   Chicken Irani Boti RS. 450\n ";	
cout<<"\t\t\t  9.   Chicken Sheesh Tao RS.450 \t\t\t 10.  Chicken Boneless Boti RS. 450\n";

cout<<endl<<endl;	
cout<<"\t\t\t\t\t\t\t Select the Item do you want !! ";
cin>>item;	
	
switch(item)
{	
case 1:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Karhai do you want..... ";
cin>>Kg;

a = 850;
s1 = s1+a*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Karhai.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;	
}	
case 2:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Boneless Handi do you want...... ";
cin>>Kg;
b = 850;
s1 = s1+b*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Boneless Handi....... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;	
}
case 3:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Achari Karhai do you want....... ";
cin>>Kg;
c = 850;
s1 = s1+c*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Achari Karhai....... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 4:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Jalfrezi do you want........ ";
cin>>Kg;
d = 400;
s1 = s1+d*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Jalfrezi......... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 5:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Green Chilli do you want......... ";
cin>>Kg;
e = 400;
s1 = s1+e*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Green Chilli....... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 6:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Green Chilli do you want.......... ";
cin>>Kg;
f = 400;
s1 = s1+f*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Green Chilli........ \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 7:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Malai Boti do you want.......... ";
cin>>Kg;
g = 450;
s1 = s1+g*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Malai Boti......... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 8:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Irani Boti do you want......... ";
cin>>Kg;
h = 450;
s1 = s1+h*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Irani Boti........ \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 9:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Sheesh Tao do you want........... ";
cin>>Kg;
i = 450;
s1 = s1+i*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Sheesh Tao........ \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!";
break;	
}
case 10:
{
cout<<"\t\t\t\t\t\t\t How many Chicken Sheesh Tao do you want......... ";
cin>>Kg;
j = 450;
s1 = s1+j*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Sheesh Tao......... \n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !!\n";
break;	
}

}

system("cls");
system("color 7C");
cout<<endl<<endl;   
cout<<"\n\t\t\t\t\t\t\t\t  THANK YOU FOR YOUR ORDER :)\n\n\n\t\t\t\t\t\t\t\tG E N E R A T I N G   B I L L ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}
cout<<"\n\t\t\t\t\t\t\t";
//system("PAUSE");

cout << "\n\t\t\t\t\t\t\t ================================================"<<endl;
cout << "\t\t\t\t\t\t\t|           ONLINE FOOD ORDER SYSTEM             |"<<endl;
cout << "\t\t\t\t\t\t\t ================================================"<<endl;
cout << endl;
cout<<"\t\t\t\t\t\t\t\t    D E A R   C U S T O M E R\n ";
cout<<endl;
cout<<"\n\t\t\t\t\t\t\t     Your Bill for Single Order is  RS. "<<s1<<endl;
char op;
cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t\t\tDo you want to another order ?\n"<<endl;
cout<<"\t\t\t\t\t\t\t   If yes press y or Y if no press any key to exit \n";
cout<<"\t\t\t\t\t\t\t\t\t    ";
cin>>op;

if (op=='y'||op=='Y')
{
	manu();
}

else 
{
	exit(0);
}
}



void Mutton()       // Definition of Mutton Function
{

int item,Kg;
int k,l,m,n,o,p,s2=0;	
system("cls");
system("color 3E");
cout<<endl<<endl<<endl;
cout<<"\t\t\t  =====================================================================================\n";
cout<<"\t\t\t  1.   Mutton Karhai RS.1700\t\t\t\t 2.   Mutton Boneless  RS.1700\n\t\t\t  3.   Mutton Achari Karhai RS.1700 \t\t\t 4.   Mutton Chanp Grill RS.800\n ";
cout<<"\t\t\t  5.   Mutton Boti RS.800 \t\t\t\t 6.   Mutton Kabab RS.400\n";   
cout<<endl<<endl;	
cout<<"\t\t\t\t\t\t\t Select the Item do you want !! ";
cin>>item;	
	
switch(item)
{
case 1:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Karhai do you want..... ";
cin>>Kg;

k = 1700;
s2 = s2+k*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Karhai.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;		
}
case 2:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Boneless do you want....."; 
cin>>Kg;
l = 1700;
s2 = s2+l*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Boneless.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;		
}
case 3:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Achari Karhai do you want....."; 
cin>>Kg;
m = 1700;
s2 = s2+m*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Achari Karhai.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;		
}
case 4:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Champ Grill do you want....."; 
cin>>Kg;
n = 800;
s2 = s2+n*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Champ Grill.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;		
}
case 5:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Boti do you want....."; 
cin>>Kg;
o = 800;
s2 = s2+o*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Boti.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;			
}
case 6:
{
cout<<"\t\t\t\t\t\t\t How many Mutton Kabab do you want....."; 
cin>>Kg;
p = 400;
s2 = s2+p*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Kabab.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;			
}
}
system("cls");
system("color 7C");
cout<<endl<<endl;   
cout<<"\n\t\t\t\t\t\t\t\t  THANK YOU FOR YOUR ORDER :)\n\n\n\t\t\t\t\t\t\t\tG E N E R A T I N G   B I L L ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}
cout<<"\n\t\t\t\t\t\t\t";
//system("PAUSE");

cout << "\n\t\t\t\t\t\t\t ================================================"<<endl;
cout << "\t\t\t\t\t\t\t|           ONLINE FOOD ORDER SYSTEM             |"<<endl;
cout << "\t\t\t\t\t\t\t ================================================"<<endl;
cout << endl;
cout<<"\t\t\t\t\t\t\t\t    D E A R   C U S T O M E R\n ";
cout<<endl;
cout<<"\n\t\t\t\t\t\t\t     Your Bill for Single Order is  RS. "<<s2<<endl;
char op;
cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t\t\tDo you want to another order ?\n"<<endl;
cout<<"\t\t\t\t\t\t\t   If yes press y or Y if no press any key to exit \n";
cout<<"\t\t\t\t\t\t\t\t\t    ";
cin>>op;
if (op=='y'||op=='Y')
{
manu();
}

else
{
Exit();
}
}



void DesiFood()  // Definition of Desifood Function
{
int item,Kg;   
int q,r,s,t,u,v,w,x,y,z,s3=0;
system("cls");
system("color 3F");
cout<<endl<<endl<<endl;
cout<<"\t\t\t  =========================================================================================\n";
cout<<"\t\t\t  1.   Beef Nehari RS.300\t\t\t\t 2.   Sada Haleem RS.150\n\t\t\t  3.   Daal Channa Sada RS.150 \t\t\t\t 4.   Daal Channa Frai RS.250\n ";
cout<<"\t\t\t  5.   Daal Mash Sada RS.150 \t\t\t\t 6.   Dall Mash Makhan Frai RS.250\n\t\t\t  7.   Kari Pakoora RS.150 \t\t\t\t 8.   Aloo Qeema RS. 300\n ";	
cout<<"\t\t\t  9.   Mix Vegetable Tawa RS.300 \t\t\t 10.  Sabzi RS. 150\n";
cout<<endl<<endl;	
cout<<"\t\t\t\t\t\t\t Select the Item do you want !! ";
cin>>item;
switch (item)
{
case 1:
{
cout<<"\t\t\t\t\t\t\t How Many Beef Nehari do you want..... ";
cin>>Kg;

q = 300;
s3 = s3+q*Kg;
cout<<"\t\t\t\t\t\t\t Your order Beef Nehari.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 2:
{
cout<<"\t\t\t\t\t\t\t How Many Sada Haleem do you want..... ";
cin>>Kg;

r = 150;
s3 = s3+r*Kg;
cout<<"\t\t\t\t\t\t\t Your order Sada Haleem.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;   
}
case 3:
{
cout<<"\t\t\t\t\t\t\t How Many Daal Channa Sada do you want..... ";
cin>>Kg;

s = 150;
s3 = s3+s*Kg;
cout<<"\t\t\t\t\t\t\t Your order Daal Channa Sada.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;   
}
case 4:
{
cout<<"\t\t\t\t\t\t\t How Many Daal Channa Frai do you want..... ";
cin>>Kg;

t = 250;
s3 = s3+t*Kg;
cout<<"\t\t\t\t\t\t\t Your order Daal Channa Frai.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 5:
{
cout<<"\t\t\t\t\t\t\t How Many Daal Mash Sada do you want..... ";
cin>>Kg;

u = 150;
s3 = s3+u*Kg;
cout<<"\t\t\t\t\t\t\t Your order Daal Mash Sada.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 6:
{
cout<<"\t\t\t\t\t\t\t How Many Daal Mash Makhan Frai do you want..... ";
cin>>Kg;

v = 250;
s3 = s3+v*Kg;
cout<<"\t\t\t\t\t\t\t Your order Daal Mash Makhan Frai.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 7:
{
cout<<"\t\t\t\t\t\t\t How Many Kari Pakora do you want..... ";
cin>>Kg;

w = 150;
s3 = s3+w*Kg;
cout<<"\t\t\t\t\t\t\t Your order Kari Pakora.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 8:
{
cout<<"\t\t\t\t\t\t\t How Many Aloo Qeema do you want..... ";
cin>>Kg;

x = 300;
s3 = s3+x*Kg;
cout<<"\t\t\t\t\t\t\t Your order Aloo Qeema.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 9:
{
cout<<"\t\t\t\t\t\t\t How Many Mix Vegetable Tawa do you want..... ";
cin>>Kg;

y = 300;
s3 = s3+y*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mix Vegetable Tawa.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 10:
{
cout<<"\t\t\t\t\t\t\t How Many Sabzi do you want..... ";
cin>>Kg;

z = 300;
s3 = s3+z*Kg;
cout<<"\t\t\t\t\t\t\t Your order Sabzi.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
}
system("cls");
system("color 7C");
cout<<endl<<endl;   
cout<<"\n\t\t\t\t\t\t\t\t  THANK YOU FOR YOUR ORDER :)\n\n\n\t\t\t\t\t\t\t\tG E N E R A T I N G   B I L L ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}
cout<<"\n\t\t\t\t\t\t\t";
//system("PAUSE");

cout << "\n\t\t\t\t\t\t\t ================================================"<<endl;
cout << "\t\t\t\t\t\t\t|           ONLINE FOOD ORDER SYSTEM             |"<<endl;
cout << "\t\t\t\t\t\t\t ================================================"<<endl;
cout << endl;
cout<<"\t\t\t\t\t\t\t\t    D E A R   C U S T O M E R\n ";
cout<<endl;
cout<<"\n\t\t\t\t\t\t\t     Your Bill for Single Order is  RS. "<<s3<<endl;
char op;
cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t\t\tDo you want to another order ?\n"<<endl;
cout<<"\t\t\t\t\t\t\t   If yes press y or Y if no press any key to exit \n";
cout<<"\t\t\t\t\t\t\t\t\t    ";
cin>>op;
if (op=='y'||op=='Y')
{
manu();
}
else
{
Exit();
}
}


void Biryani()   // Definition of Biryani Function
{
int item,Kg;
int ab,ac,ad,ae,af,ag,ah,ai,s4=0; 
system("cls");
system("color 0E");
cout<<endl<<endl<<endl;
cout<<"\t\t\t  =================================================================================\n";
cout<<"\t\t\t  1.   Chicken Biryani RS.180\t\t\t\t 2.   Mutton Biryani RS.380\n\t\t\t  3.   Beef Biryani RS.250 \t\t\t\t 4.   Aloo Biryani RS.120\n ";
cout<<"\t\t\t  5.   Fish Biryani RS.380 \t\t\t\t 6.   White Biryani RS.200\n\t\t\t  7.   Chinese Biryani RS.200 \t\t\t\t 8.   Prawn Biryani RS. 400\n ";  
cout<<endl<<endl;	
cout<<"\t\t\t\t\t\t\t Select the Item do you want !! ";
cin>>item;
switch (item)
{
case 1:
{
cout<<"\t\t\t\t\t\t\t How Many Chicken Biryani do you want..... ";
cin>>Kg;
ab = 180;
s4 = s4+ab*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chicken Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 2:
{
cout<<"\t\t\t\t\t\t\t How Many Mutton Biryani do you want.....";
cin>>Kg;
ac = 380;
s4 = s4+ac*Kg;
cout<<"\t\t\t\t\t\t\t Your order Mutton Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 3:
{
cout<<"\t\t\t\t\t\t\t How Many Beef Biryani do you want.....";
cin>>Kg;
ad = 250;
s4 = s4+ad*Kg;
cout<<"\t\t\t\t\t\t\t Your order Beef Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 4:
{
cout<<"\t\t\t\t\t\t\t How Many Aloo Biryani do you want.....";
cin>>Kg;
ae = 120;
s4 = s4+ae*Kg;
cout<<"\t\t\t\t\t\t\t Your order Aloo Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}    
case 5:
{
cout<<"\t\t\t\t\t\t\t How Many Fish Biryani do you want.....";
cin>>Kg;
af = 380;
s4 = s4+af*Kg;
cout<<"\t\t\t\t\t\t\t Your order Fish Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 6:
{
cout<<"\t\t\t\t\t\t\t How Many White Biryani do you want.....";
cin>>Kg;
ag = 200;
s4 = s4+ag*Kg;
cout<<"\t\t\t\t\t\t\t Your order White Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 7:
{
cout<<"\t\t\t\t\t\t\t How Many Chinese Biryani do you want.....";
cin>>Kg;
ah = 200;
s4 = s4+ah*Kg;
cout<<"\t\t\t\t\t\t\t Your order Chinese Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}                   
case 8:
{
cout<<"\t\t\t\t\t\t\t How Many Prawn Biryani do you want.....";
cin>>Kg;
ai = 400;
s4 = s4+ai*Kg;
cout<<"\t\t\t\t\t\t\t Your order Prawn Biryani.......\n ";
cout<<"\t\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
}
system("cls");
system("color 7C");
cout<<endl<<endl;   
cout<<"\n\t\t\t\t\t\t\t\t  THANK YOU FOR YOUR ORDER :)\n\n\n\t\t\t\t\t\t\t\tG E N E R A T I N G   B I L L ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}
cout<<"\n\t\t\t\t\t\t\t";
//system("PAUSE");

cout << "\n\t\t\t\t\t\t\t ================================================"<<endl;
cout << "\t\t\t\t\t\t\t|           ONLINE FOOD ORDER SYSTEM             |"<<endl;
cout << "\t\t\t\t\t\t\t ================================================"<<endl;
cout << endl;
cout<<"\t\t\t\t\t\t\t\t    D E A R   C U S T O M E R\n ";
cout<<endl;
cout<<"\n\t\t\t\t\t\t\t     Your Bill for Single Order is  RS. "<<s4<<endl;
char op;
cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t\t\tDo you want to another order ?\n"<<endl;
cout<<"\t\t\t\t\t\t\t   If yes press y or Y if no press any key to exit \n";
cout<<"\t\t\t\t\t\t\t\t\t    ";
cin>>op;
if (op=='y'||op=='Y')
{
manu();
}

else
{
Exit();
}
}


void Burger()          // Definition of Burger Function
{
int item, Kg;   
int bc,bd,be,bf,s5=0;
system("cls");
system("color 0F");
cout<<endl<<endl<<endl;
cout<<"\t\t\t\t  =================================================================\n";
cout<<"\t\t\t\t  1.   Zinger Burger RS.280\t\t 2.   Chapli Burger RS.380\n\t\t\t\t  3.   Egg Burger RS.150 \t\t 4.   Chicken Burger RS.180\n ";
cout<<endl<<endl;	
cout<<"\t\t\t\t\t\t Select the Item do you want !! ";
cin>>item;

switch(item)
{
case 1:
{
cout<<"\t\t\t\t\t\t How Many Zinger Burger do you want.....";
cin>>Kg;
bc = 280;
s5 = s5+bc*Kg;
cout<<"\t\t\t\t\t\t Your order Zinger Burger.......\n ";
cout<<"\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 2:
{
cout<<"\t\t\t\t\t\t How Many Chapli Burger do you want.....";
cin>>Kg;
bd = 380;
s5 = s5+bd*Kg;
cout<<"\t\t\t\t\t\t Your order Chapli Burger.......\n ";
cout<<"\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 3:
{
cout<<"\t\t\t\t\t\t How Many Egg Burger do you want.....";
cin>>Kg;
be = 150;
s5 = s5+be*Kg;
cout<<"\t\t\t\t\t\t Your order Egg Burger.......\n ";
cout<<"\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
case 4:
{
cout<<"\t\t\t\t\t\t How Many Chicken Burger do you want.....";
cin>>Kg;
bf = 180;
s5 = s5+bf*Kg;
cout<<"\t\t\t\t\t\t Your order Chicken Burger.......\n ";
cout<<"\t\t\t\t\t\t Your order Successfully saved !! ";
break;
}
}
system("cls");
system("color 7C");
cout<<endl<<endl;   
cout<<"\n\t\t\t\t\t\t\t\t  THANK YOU FOR YOUR ORDER :)\n\n\n\t\t\t\t\t\t\t\tG E N E R A T I N G   B I L L ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}
cout<<"\n\t\t\t\t\t\t\t";
//system("PAUSE");

cout << "\n\t\t\t\t\t\t\t ================================================"<<endl;
cout << "\t\t\t\t\t\t\t|           ONLINE FOOD ORDER SYSTEM             |"<<endl;
cout << "\t\t\t\t\t\t\t ================================================"<<endl;
cout << endl;
cout<<"\t\t\t\t\t\t\t\t    D E A R   C U S T O M E R\n ";
cout<<endl;
cout<<"\n\t\t\t\t\t\t\t     Your Bill for Single Order is  RS. "<<s5<<endl;
char op;
cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t\t\tDo you want to another order ?\n"<<endl;
cout<<"\t\t\t\t\t\t\t   If yes press y or Y if no press any key to exit \n";
cout<<"\t\t\t\t\t\t\t\t\t    ";
cin>>op;
if (op=='y'||op=='Y')
{
	manu();
}

else
{
   Exit();
}
}


void Main()
{
cout<<endl<<endl<<endl;
system("cls");   
system("color 3E"); 
cout<<endl<<endl<<endl;
cout<<"\t\t\t\t\t\t 1: Registeration\n";
cout<<"\t\t\t\t\t\t 2: Login\n"; 
cout<<"\t\t\t\t\t\t 3: Exit\n";
cout<<"\n\n\t\t\t\t\t\t Enter your Choice\t";
int ch;
cin>>ch;
switch(ch)
{   
case 1:
{
Registration();        // Calling Registration Function
break;	
}	
case 2:
{
Login();              // Calling Login Function
break;	
}	
case 3:
{
Exit();	             // Calling manu Function
break;
}	
default:
{
cout<<"\n\n\t\t\t\t\t\t\a Invalid Choice\t\t";

}	
}
	
	
	
}

void Welcome()
{
 system("cls");
 system("color 8E");
int in=200,a=201,b=186,c=204,d=205,e=187,f=188,g=185;

cout<<"\n\t\t\t\t\t L O A D I N G ";
for(int a=1;a<8;a++) // Change 'a<?' to how many * you want
{
Sleep(500);
cout << "...";
}   

cout<<endl<<endl<<endl<<endl;

cout<<setw(32)<<char(a)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(e)<<setw(7)<<char(a)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(g)<<setw(7)<<char(a)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(g)<<endl;
cout<<setw(32)<<char(b)<<setw(13)<<char(b)<<setw(7)<<char(b)<<setw(19)<<char(b)<<endl<<setw(32)<<char(b)<<setw(13)<<char(b)<<setw(7)<<char(b)<<setw(19)<<char(b)<<endl<<setw(32)<<char(b)<<setw(13)<<char(b)<<setw(7)<<char(c)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(g)<<setw(7)<<char(in)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(e)<<endl;
cout<<setw(32)<<char(b)<<setw(13)<<char(b)<<setw(7)<<char(b)<<setw(31)<<char(b)<<endl<<setw(32)<<char(b)<<setw(13)<<char(b)<<setw(7)<<char(b)<<setw(31)<<char(b)<<endl;
cout<<setw(32)<<char(in)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(f)<<setw(7)<<char(in)<<setw(19)<<char(c)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(f);
cout<<endl;
cout<<"\n\n\t\t\t\t      [ O N L I N E   F O O D   S Y S T E M ]";
//cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
cout<<"\n\n\n"<<setw(37)<<char(a)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(e)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<" Made By \t    :   Abdul Rasheed\t"<<setw(7)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<setw(42)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<" Roll Number   :   20CS016\t\t"<<setw(7)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<setw(42)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<" Section \t    :   (ii)"<<setw(19)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<setw(42)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<" Subject\t    : Computer Programming  "<<setw(3)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<setw(42)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<" Submitted to  :   Sir Rizwan Baloch"<<setw(6)<<char(b)<<endl;
cout<<"\t\t\t\t"<<setw(5)<<char(b)<<setw(42)<<char(b)<<endl;
cout<<"\t"<<setw(29)<<char(in)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(d)<<char(f);
	
}


void Exit()           // Definition of Exit Function     
{	
exit(0);	
}

